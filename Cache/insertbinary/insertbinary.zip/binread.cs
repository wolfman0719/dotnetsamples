﻿// binread.cs

using System;
using System.IO;

CacheCommand			spCache;
CacheConnection		cnCache;
CacheDataAdapter		daCache;
CacheTransaction		txCache=null;
DataSet				dsCache;
DataTable			dtCache;
DataRow				drCache;

class BinaryRead {
  static void Main(string[] args) {

    //存在するファイルを指定する
    FileStream fs = new FileStream(
      @"c:\temp\picture\xxx.jpeg", FileMode.Open, FileAccess.Read);

    int fileSize = (int)fs.Length; // ファイルのサイズ
    byte[] buf = new byte[fileSize]; // データ格納用配列

    int readSize; // Readメソッドで読み込んだバイト数
    int remain = fileSize; // 読み込むべき残りのバイト数
    int bufPos = 0; // データ格納用配列内の追加位置


    readSize = fs.Read(buf, 0, fs.Length)

    string cacheConnectString = "Server = localhost;Port=1972;Namespace=User;Password=SYS;User ID = _SYSTEM;";
    cnCache = new CacheConnection(cacheConnectString);
    cnCache.Open();
    spCache = new CacheCommand("Insert into MyApp.Person2(Name, Picture) Values(?, ?)", cnCache, txCache);
				
    CacheParameter	pName	= new CacheParameter();
    pName.ParameterName		= "Name";
    pName.CacheDbType		= CacheDbType.NVarChar;
    pName.Direction			= ParameterDirection.Input;
    pName.Value				= "Hoge Hoge;

    CacheParameter	pPicture = new CacheParameter();
    pDOB.ParameterName		= "Picture";
    pName.CacheDbType		= CacheDbType.LONGVARBINARY;
    pDOB.Direction		= ParameterDirection.Input;
    pDOB.Value				= buf;

    spCache.ExecuteNonQuery();

    fs.Dispose();
    cnCache.close();
  }
}

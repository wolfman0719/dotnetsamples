﻿1. myappperson.xmlをuserネームスペースにインポート

ファイル>ネームスペース変更

USERネームスペースを選択

スタジオ>ツール>ローカルからインポート

2.　binread.csをMicrosoft VSでビルド

参照設定

c:\intersystems\cache\dev\dotnet\bin\v4.0.30319\InterSystems.Data.CacheClient.dll

V4.0.xxxはCacheのバージョンにより違いがある可能性あり

3.　ビルド&テスト

ビルド後に実行するとc:\tempの下に

??????????.streamという形式の名前のファイルが作成されている

このファイルをビュワーやペイントツールでオープンして、元々のファイルと同じ内容か確認

4.　備考

4.1　ファイルの準備

jpeg等のファイルを自分で準備、それにソース上のファイル名を合わせる

4.2　ファイルの出力先

定義上、c:\tempとなっている。

都合が悪い場合には、MyApp.Person2の定義を書き換える（Location）